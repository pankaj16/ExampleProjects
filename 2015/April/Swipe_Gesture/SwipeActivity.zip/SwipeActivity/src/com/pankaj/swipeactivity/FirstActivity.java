package com.pankaj.swipeactivity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;

public class FirstActivity extends Activity {

	private GestureDetectorCompat gestureDetectorCompat;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_first);
		
		gestureDetectorCompat = new GestureDetectorCompat(this, new MyGestureListener());
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		this.gestureDetectorCompat.onTouchEvent(event);
        return super.onTouchEvent(event);
	}
	
	class MyGestureListener extends GestureDetector.SimpleOnGestureListener {
		//handle 'swipe left' action only

        @Override
        public boolean onFling(MotionEvent event1, MotionEvent event2, 
                float velocityX, float velocityY) {
            
        	/*
        	Toast.makeText(getBaseContext(), 
        		event1.toString() + "\n\n" +event2.toString(), 
        		Toast.LENGTH_SHORT).show();
        	*/
        	
        	if(event2.getX() < event1.getX()){
        		Toast.makeText(getBaseContext(), 
        			"Swipe left - Start Second Activity()", 
        			Toast.LENGTH_SHORT).show();
        		
        		//switch another activity
            	Intent intent = new Intent(
            			FirstActivity.this, SecondActivity.class);
            	startActivity(intent);
            	overridePendingTransition(R.anim.slide_left_in, R.anim.slide_left_out);
        	}

            return true;
        }
    }
}
