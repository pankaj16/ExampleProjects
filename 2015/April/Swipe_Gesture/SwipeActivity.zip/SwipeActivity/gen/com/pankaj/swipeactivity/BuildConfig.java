/** Automatically generated file. DO NOT MODIFY */
package com.pankaj.swipeactivity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}