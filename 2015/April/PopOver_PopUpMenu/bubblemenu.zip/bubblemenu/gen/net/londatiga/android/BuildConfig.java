/** Automatically generated file. DO NOT MODIFY */
package net.londatiga.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}